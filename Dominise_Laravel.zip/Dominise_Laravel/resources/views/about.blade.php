@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">About</div>

                <div class="panel-body">
                <p>
                    

I Diana Grace Dominise from Tabada Mambaling Cebu City.Taking up of Bachelor of Science Information 
Teachnology in University Of Cebu . Im am the youngest of three . I love Supports Like PBA. My Hobbies 
is Playing Soccer , SoftBall, Running, Swimming. Im From Beautiful Place of Mindanao In Medina Misamis 
Oriental. Name of My Father is Alexander Dominise occupation is Fisherman and My Mothers Name is Alicia 
Dominise occupation housewife, my brother and sister are working my elder brother is seaman and hes 
graduated in METC- University Of Cebu and my sister is not finish here studies because of her some filed 
subject and now she is working as OFW in Kuwait.<br><br>&nbsp;&nbsp;&nbsp;&nbsp; My Primary School in Governor Pelaez Elementary School 
my Secondary is in Medina National Comprehensive High School.  I had a lot of plans for my family. I 
want to help them and give them a good life, give their want they want and  needs.  I have a dream to go 
other country together with my family. I want to my family proud of me of what those of my decision 
making to be success and they support me even in my sexual orentation and im so thankful i have the 
family to support me always.<br><br> &nbsp;&nbsp;&nbsp;&nbsp; I know my situation is very difficult to solve those problem that I face. 
I won’t to field them because of the trials that gods give me strength to face the trials like financial 
problem . My goal to my self is to prove them that I can reach for my dream to become a web designer . I 
know this is not easy to reach my goal I need to process a lot of things that I wanted to be learn for 
my self. If I graduate this coming 2017 I think I can do all of my want and needs to myself. I can 
travel all over the world if I success to become a web designer.<br><br> &nbsp;&nbsp;&nbsp;&nbsp; My promises to myself is to achieve my 
successful decision making and prove to all people who always bring me down and talking behind my back 
that i cant make all  of this that I can do everything in the good way thank you.

                </p>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
