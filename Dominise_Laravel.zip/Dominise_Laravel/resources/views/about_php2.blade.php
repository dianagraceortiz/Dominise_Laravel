@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">About PHP2</div>

                <div class="panel-body">
                <p>
                           
                        
                        PHP is a server-side scripting language designed primarily for web development 
                        but also used as a general-purpose programming language. Originally created by 
                        Rasmus Lerdorf in 1994,[4] the PHP reference implementation is now produced by 
                        The PHP Development Team.[5] PHP originally stood for Personal Home Page,[4] but 
                        it now stands for the recursive acronym PHP: Hypertext Preprocessor.[6]
                        <br><br>
                        PHP code may be embedded into HTML or HTML5 markup, or it can be used in 
                        combination with various web template systems, web content management systems 
                        and web frameworks. PHP code is usually processed by a PHP interpreter 
                        implemented as a module in the web server or as a Common Gateway Interface (CGI) 
                        executable. The web server software combines the results of the interpreted and 
                        executed PHP code, which may be any type of data, including images, with the 
                        generated web page. PHP code may also be executed with a command-line interface (
                        CLI) and can be used to implement standalone graphical applications.[7]
                        <br><br>
                        The standard PHP interpreter, powered by the Zend Engine, is free software 
                        released under the PHP License. PHP has been widely ported and can be deployed 
                        on most web servers on almost every operating system and platform, free of 
                        charge.[8]
                        <br><br>
                        The PHP language evolved without a written formal specification or standard 
                        until 2014, leaving the canonical PHP interpreter as a de facto standard. Since 
                        2014 work has gone on to create a formal PHP specification.[9]
                </p>

                </div>
            </div>
        </div>
    </div>
</div>
@endsection
