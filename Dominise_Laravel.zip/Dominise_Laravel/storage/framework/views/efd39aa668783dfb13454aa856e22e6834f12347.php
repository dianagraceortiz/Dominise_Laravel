<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">Educational Background</div>

                <div class="panel-body">
                    <p>
                        Tabada Mambaling Cebu City<br>
09974402709<br>
dianagracedominise25@gmail.com<br>


<br><br><b>Diana Grace Dominise</b> <br> <br>                               

<b>PERSONAL DATA</b><br><br>
    Date of Birth&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; June 16, 1995<br>
    Place of Birth&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;     Gingoog City<br>
    Civil Status &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;           Single<br>
    Citizenship&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;        Filipino<br>
    Religion &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;          Catholic<br>
    Father’s Name &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;      Alexander Dominise<br>
    Mother’s Name &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;      Alicia Dominise<br><br>


<b>EDUCATIONAL BACKGROUND</b><br><br>
    Primary     Governor Pelaez Elementary School<br>
                Cabug Medina Misamis Oriental<br><br>

Secondary       Medina National Comprehensive High School<br>
                North Poblacion Medina Misamis Oriental<br><br>
    
Tertiary        University of Cebu Main Campus (Still Studying)<br>
                Sanciangko St. Cebu City<br><br>

                    </p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>